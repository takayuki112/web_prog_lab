from django import forms

class StudentForm(forms.Form):
    name = forms.CharField(label='Name', max_length=100)
    dob = forms.DateField(label='Date of Birth', widget=forms.SelectDateWidget(years=range(1990, 2026)))
    address = forms.CharField(label='Address', widget=forms.Textarea)
    contact_number = forms.CharField(label='Contact Number', max_length=15)
    email = forms.EmailField(label='Email ID')
    english_marks = forms.IntegerField(label='English Marks', min_value=0, max_value=100)
    physics_marks = forms.IntegerField(label='Physics Marks', min_value=0, max_value=100)
    chemistry_marks = forms.IntegerField(label='Chemistry Marks', min_value=0, max_value=100)
