from django.apps import AppConfig


class TeacherFormConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'teacher_form'
