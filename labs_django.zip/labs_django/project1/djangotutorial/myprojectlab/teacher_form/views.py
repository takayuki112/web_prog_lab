from django.shortcuts import render
from .forms import StudentForm

def student_form(request):
    form = StudentForm()
    student_details = None
    percentage = None

    if request.method == 'POST':
        form = StudentForm(request.POST)
        if form.is_valid():
            name = form.cleaned_data['name']
            dob = form.cleaned_data['dob']
            address = form.cleaned_data['address']
            contact_number = form.cleaned_data['contact_number']
            email = form.cleaned_data['email']
            english_marks = form.cleaned_data['english_marks']
            physics_marks = form.cleaned_data['physics_marks']
            chemistry_marks = form.cleaned_data['chemistry_marks']

            total_marks = english_marks + physics_marks + chemistry_marks
            percentage = (total_marks / 300) * 100

            student_details = f"""
            Name: {name}
            Date of Birth: {dob}
            Address: {address}
            Contact Number: {contact_number}
            Email ID: {email}
            English Marks: {english_marks}
            Physics Marks: {physics_marks}
            Chemistry Marks: {chemistry_marks}
            Total Percentage: {percentage:.2f}%
            """

    return render(request, 'teacher_form/student_form.html', {'form': form, 'student_details': student_details, 'percentage': percentage})
