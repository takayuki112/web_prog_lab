from django.shortcuts import render

# A view in django recieves a HTTP Request and returns a HTTP Response
# A view can be mapped to a url in urls.py

def index(request):
    name = ''
    message = ''
    formatted_message = ''
    style = ''
    color = 'black'

    if request.method == 'POST':
        name = request.POST.get('name', '')
        message = request.POST.get('message', '')
        style = request.POST.get('style', '')
        color = request.POST.get('color', 'black')

        formatted_message = f"Name: {name} <br>Message: {message}"
        if 'bold' in request.POST:
            formatted_message = f"<b>{formatted_message}</b>"
        if 'italic' in request.POST:
            formatted_message = f"<i>{formatted_message}</i>"
        if 'underline' in request.POST:
            formatted_message = f"<u>{formatted_message}</u>"

    # The render() function takes three arguments:
    # 1. The request object.
    # 2. The path to the template file 
    # 3. A dictionary of context data 

    return render(request, 'message/index.html', {
        'formatted_message': formatted_message,
        'style': style,
        'color': color,
    })

    # Django's template engine processes the template file, replaces placeholders 
    # (e.g., {{ formatted_message }}
